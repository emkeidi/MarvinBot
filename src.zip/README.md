# MarvinBot

MarvinBot is a Discord bot that uses OpenAI to seem like a depressed chatbot.

Don't worry too much about Marvin, though, he'll be fine.

MarvinBot has a built-in Minecraft stat generator, too, even if he's not a big fan.

At this time, the bot pulls player data from .json files stores in /src/commands/playerStats. There is probably a better place to keep these files within the project.

Next goal would be to host the player data files somewhere like S3 and add the ability to upload new files. Player stats appear tied to the world.
