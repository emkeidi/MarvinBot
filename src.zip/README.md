# MarvinBot

MarvinBot is a Discord bot that uses OpenAI to seem like a depressed chatbot.

Don't worry too much about Marvin, though, he'll be fine.
